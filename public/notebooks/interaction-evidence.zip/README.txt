Interaction executed Python core results. R and specialist extensions were not rerun. Gallery examples labeled synthetic are not empirical evidence.
Python widgets require Colab/Jupyter. No peer feedback is fabricated. Source units and boundaries are documented in the notebook.
